import React, { useState } from 'react';
import { 
  FileSearch,
  UploadCloud, 
  File, 
  AlertCircle, 
  CheckCircle, 
  ChevronRight, 
  RefreshCw, 
  Copy, 
  Check, 
  Binary, 
  Search, 
  MessageSquare, 
  Hash, 
  Terminal,
  ImageIcon,
  HardDrive,
  FileSpreadsheet,
  Download
} from 'lucide-react';
import { analyzeFile } from '../api/client';
import { FlagCard } from '../components/FlagCard';
import { useApp } from '../context/AppContext';

interface ForensicsProps {
  onNavigateToChat?: () => void;
}

export const Forensics: React.FC<ForensicsProps> = ({ onNavigateToChat }) => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Tabs inside results
  const [activeTab, setActiveTab] = useState<'pipeline' | 'hexdump' | 'strings' | 'artifacts'>('pipeline');
  const [stringFilter, setStringFilter] = useState('');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const { setChatContext } = useApp();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeFile(file);
      setResult(data);
      if (data.extracted_image_data_uri || data.dd_details || data.evtx_summary) {
        setActiveTab('artifacts');
      }
    } catch (err: any) {
      setError(err.message || 'Analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const handleCopyText = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedHash(type);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const handleAskAI = () => {
    if (!result) return;
    const summary = `Challenge File: ${file?.name} (${file?.size} bytes)
Status: ${result.status}
Magic Bytes: ${JSON.stringify(result.steps?.[0]?.result || {})}
Hints: ${JSON.stringify(result.hints || [])}
Extracted Strings Count: ${result.file_meta?.strings_count || 0}`;
    setChatContext(summary);
    if (onNavigateToChat) {
      onNavigateToChat();
    }
  };

  const filteredStrings = (result?.file_meta?.sample_strings || []).filter((s: string) =>
    s.toLowerCase().includes(stringFilter.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-semibold font-sans text-slate-100 flex items-center gap-2">
            <FileSearch className="w-5 h-5 text-emerald-400" />
            Digital Artifact & File Forensics
          </h2>
          <p className="text-slate-400 text-xs mt-1 font-sans">
            Multi-layer automated analysis: PCAP network traffic, Windows EVTX event logs, raw disk images, embedded artifacts, and header verification.
          </p>
        </div>

        {result && (
          <button
            onClick={handleAskAI}
            className="flex items-center gap-2 px-3 py-1.5 rounded bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-200 text-xs font-sans transition-colors"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <span>Consult AI Advisor</span>
          </button>
        )}
      </div>

      {/* Upload Zone */}
      <div className="bg-cyber-card border border-cyber-border rounded-xl p-6">
        <label className="border-2 border-dashed border-cyber-border hover:border-cyber-green/50 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer transition-all bg-cyber-dark/40 hover:bg-cyber-dark/80 group">
          <UploadCloud className="w-12 h-12 text-gray-500 group-hover:text-cyber-green transition-colors mb-3" />
          <span className="text-sm font-medium text-gray-300 group-hover:text-white">
            {file ? file.name : "Click to select or drag and drop challenge file"}
          </span>
          <span className="text-xs text-gray-500 mt-1 font-mono">
            Accepts PCAP, EVTX, .dd, images, archives, memory dumps, or corrupted headers
          </span>
          <input type="file" className="hidden" onChange={handleFileChange} />
        </label>

        {file && (
          <div className="mt-4 flex items-center justify-between bg-cyber-dark px-4 py-3 rounded-lg border border-cyber-border">
            <div className="flex items-center gap-3">
              <File className="w-5 h-5 text-cyber-cyan" />
              <div>
                <p className="text-sm font-mono text-white">{file.name}</p>
                <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
            </div>
            <button
              onClick={handleAnalyze}
              disabled={loading}
              className="flex items-center gap-2 px-5 py-2 rounded-lg bg-cyber-green text-black font-semibold text-sm hover:bg-cyber-green/90 disabled:opacity-50 transition-all font-mono"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Analyzing Pipeline...
                </>
              ) : (
                'Run Deep Forensics'
              )}
            </button>
          </div>
        )}
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-3 text-red-200">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-sm">Analysis Error</h4>
            <p className="text-xs text-red-300 mt-0.5 font-mono">{error}</p>
          </div>
        </div>
      )}

      {/* Results View */}
      {result && (
        <div className="space-y-6">
          {/* Flags Banner */}
          <FlagCard flags={result.flags_found || []} source={`Forensics (${file?.name})`} />

          {/* Extracted Image Preview (Featured in mac-voice-assistant) */}
          {result.extracted_image_data_uri && (
            <div className="border border-cyber-green/40 bg-black/80 rounded-xl p-5 space-y-3 glow-green">
              <div className="flex items-center justify-between text-xs font-mono text-cyber-green font-bold">
                <span className="flex items-center gap-2">
                  <ImageIcon className="w-4 h-4" />
                  DECODED IMAGE ARTIFACT
                </span>
                <span className="text-gray-400">{result.extracted_file?.split('/').pop()}</span>
              </div>
              <div className="flex justify-center bg-black/95 p-4 rounded-lg border border-neutral-800">
                <img 
                  src={result.extracted_image_data_uri} 
                  alt="Extracted Artifact" 
                  className="max-h-80 object-contain rounded border border-cyber-border shadow-lg" 
                />
              </div>
            </div>
          )}

          {/* Hashes & File Meta */}
          {result.file_meta && (
            <div className="bg-cyber-card border border-cyber-border rounded-xl p-5 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-cyber-border pb-2">
                <span className="text-gray-400 uppercase font-bold flex items-center gap-1.5">
                  <Hash className="w-4 h-4 text-cyber-cyan" /> Cryptographic Hashes
                </span>
                <div className="flex items-center gap-3">
                  <a
                    href="http://localhost:8000/api/forensics/download-extracted"
                    download="shadowsolve_carved_artifacts.zip"
                    className="flex items-center gap-1.5 px-3 py-1 rounded bg-cyber-green/10 border border-cyber-green/40 hover:bg-cyber-green/20 text-cyber-green text-xs font-mono transition-all"
                    title="Download all extracted and carved files as a .zip"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Carved Artifacts (.zip)</span>
                  </a>
                  <span className="text-gray-500">Size: {result.file_meta.size_bytes} bytes</span>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {['md5', 'sha1', 'sha256'].map((hType) => (
                  <div key={hType} className="bg-cyber-darker p-2.5 rounded border border-cyber-border flex items-center justify-between">
                    <div className="truncate mr-2">
                      <span className="text-gray-500 block text-[10px] uppercase">{hType}</span>
                      <span className="text-gray-300 select-all truncate block">{result.file_meta[hType]}</span>
                    </div>
                    <button
                      onClick={() => handleCopyText(result.file_meta[hType], hType)}
                      className="p-1 text-gray-400 hover:text-white"
                      title="Copy Hash"
                    >
                      {copiedHash === hType ? <Check className="w-3.5 h-3.5 text-cyber-green" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Hints & Recommendations */}
          {result.hints && result.hints.length > 0 && (
            <div className="bg-cyber-card border border-yellow-500/30 rounded-xl p-5">
              <h3 className="text-sm font-bold font-mono text-yellow-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                <span>💡</span> Pipeline Discoveries & Artifacts
              </h3>
              <ul className="space-y-1.5 text-sm text-gray-300 font-mono">
                {result.hints.map((hint: string, idx: number) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-yellow-400 font-bold">•</span>
                    <span>{hint}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Sub-Tabs: Pipeline, Hexdump, Strings, Artifacts */}
          <div className="bg-cyber-card border border-cyber-border rounded-xl overflow-hidden">
            <div className="flex border-b border-cyber-border bg-cyber-darker px-4 pt-2 gap-2 overflow-x-auto">
              <button
                onClick={() => setActiveTab('pipeline')}
                className={`px-4 py-2 text-xs font-mono rounded-t-lg transition-colors border-t border-x ${
                  activeTab === 'pipeline'
                    ? 'bg-cyber-card border-cyber-green/50 text-cyber-green font-bold'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                Pipeline Steps ({result.steps?.length || 0})
              </button>
              {(result.dd_details || result.evtx_summary || result.memory_details) && (
                <button
                  onClick={() => setActiveTab('artifacts')}
                  className={`px-4 py-2 text-xs font-mono rounded-t-lg transition-colors border-t border-x ${
                    activeTab === 'artifacts'
                      ? 'bg-cyber-card border-yellow-500/50 text-yellow-400 font-bold'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  Deep Artifacts (Disk/EVTX)
                </button>
              )}
              <button
                onClick={() => setActiveTab('hexdump')}
                className={`px-4 py-2 text-xs font-mono rounded-t-lg transition-colors border-t border-x ${
                  activeTab === 'hexdump'
                    ? 'bg-cyber-card border-cyber-cyan/50 text-cyber-cyan font-bold'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                Hex Dump (1KB)
              </button>
              <button
                onClick={() => setActiveTab('strings')}
                className={`px-4 py-2 text-xs font-mono rounded-t-lg transition-colors border-t border-x ${
                  activeTab === 'strings'
                    ? 'bg-cyber-card border-purple-500/50 text-purple-300 font-bold'
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                Extracted Strings ({result.file_meta?.strings_count || 0})
              </button>
            </div>

            <div className="p-5">
              {activeTab === 'pipeline' && (
                <div className="space-y-3">
                  {result.steps?.map((st: any, idx: number) => {
                    const hasFlag = st.result?.flags_found && st.result.flags_found.length > 0;
                    return (
                      <div 
                        key={idx}
                        className={`border rounded-lg p-3.5 bg-cyber-darker/60 font-mono text-xs ${
                          hasFlag ? 'border-cyber-green/50 bg-cyber-green/5' : 'border-cyber-border'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-white font-semibold text-sm flex items-center gap-2">
                            {hasFlag ? (
                              <CheckCircle className="w-4 h-4 text-cyber-green" />
                            ) : (
                              <ChevronRight className="w-4 h-4 text-gray-500" />
                            )}
                            {st.step}
                          </span>
                          {hasFlag && (
                            <span className="bg-cyber-green/20 text-cyber-green px-2 py-0.5 rounded text-[10px] font-bold">
                              FLAG FOUND
                            </span>
                          )}
                        </div>
                        <pre className="text-gray-400 overflow-x-auto p-2 bg-black/40 rounded mt-2 select-all">
                          {typeof st.result === 'object' 
                            ? JSON.stringify(st.result, null, 2) 
                            : String(st.result)}
                        </pre>
                      </div>
                    );
                  })}
                </div>
              )}

              {activeTab === 'artifacts' && (
                <div className="space-y-4 font-mono text-xs">
                  {/* Disk Details */}
                  {result.dd_details && (
                    <div className="space-y-3">
                      <h4 className="text-cyber-green font-bold flex items-center gap-2">
                        <HardDrive className="w-4 h-4" /> Disk Partitions & Files
                      </h4>
                      <div className="bg-cyber-darker p-3 rounded-lg border border-cyber-border space-y-2">
                        <div>Partitions Found: {result.dd_details.partitions?.length || 0}</div>
                        <div className="text-gray-400">
                          {result.dd_details.files_found?.length ? `Extracted Files: ${result.dd_details.files_found.join(', ')}` : 'No loose files extracted.'}
                        </div>
                        {result.dd_details.carved_files?.length > 0 && (
                          <div className="text-yellow-400">
                            Carved Files: {JSON.stringify(result.dd_details.carved_files)}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* EVTX Summary */}
                  {result.evtx_summary && (
                    <div className="space-y-3">
                      <h4 className="text-cyber-cyan font-bold flex items-center gap-2">
                        <FileSpreadsheet className="w-4 h-4" /> Windows Event Log Summary
                      </h4>
                      <div className="bg-cyber-darker p-3 rounded-lg border border-cyber-border space-y-2">
                        <div>Total Events Parsed: {result.evtx_summary.total_events}</div>
                        {result.evtx_summary.powershell_commands?.length > 0 && (
                          <div>
                            <span className="text-orange-400 block mb-1">PowerShell Commands:</span>
                            <pre className="p-2 bg-black/60 rounded text-gray-300">
                              {JSON.stringify(result.evtx_summary.powershell_commands, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'hexdump' && (
                <div>
                  <pre className="bg-black/70 p-4 rounded-lg font-mono text-xs text-cyber-cyan overflow-x-auto select-all leading-relaxed">
                    {result.file_meta?.hexdump || 'No hexdump available'}
                  </pre>
                </div>
              )}

              {activeTab === 'strings' && (
                <div className="space-y-3">
                  <div className="relative">
                    <input
                      type="text"
                      value={stringFilter}
                      onChange={(e) => setStringFilter(e.target.value)}
                      placeholder="Filter strings (e.g. flag, key, admin, pass, http)..."
                      className="w-full bg-cyber-darker border border-cyber-border rounded-lg pl-9 pr-3 py-2 text-xs font-mono text-white placeholder-gray-500 focus:outline-none focus:border-purple-500/60"
                    />
                    <Search className="w-4 h-4 text-gray-500 absolute left-3 top-2.5" />
                  </div>

                  <div className="max-h-96 overflow-y-auto space-y-1 bg-black/60 p-3 rounded-lg border border-cyber-border">
                    {filteredStrings.length === 0 ? (
                      <p className="text-xs font-mono text-gray-500 text-center py-4">No matching strings</p>
                    ) : (
                      filteredStrings.map((s: string, idx: number) => (
                        <div key={idx} className="font-mono text-xs text-gray-300 hover:text-white select-all py-0.5 border-b border-gray-900/40">
                          {s}
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
