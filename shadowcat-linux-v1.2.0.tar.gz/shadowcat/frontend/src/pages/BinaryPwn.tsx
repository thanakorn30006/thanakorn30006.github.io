import React, { useState } from 'react';
import { 
  FileCode2, 
  UploadCloud, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  Cpu, 
  ShieldCheck, 
  Terminal, 
  Flame 
} from 'lucide-react';
import { inspectBinary } from '../api/client';
import { FlagCard } from '../components/FlagCard';

export const BinaryPwn: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleInspect = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await inspectBinary(file);
      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Binary inspection failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="border-b border-slate-800 pb-4">
        <h2 className="text-xl font-semibold font-sans text-slate-100 flex items-center gap-2">
          <FileCode2 className="w-5 h-5 text-emerald-400" />
          Binary Mitigations (Checksec) & Dangerous Function Audit
        </h2>
        <p className="text-slate-400 text-xs mt-1 font-sans">
          Executable analysis (ELF & PE): NX/DEP, Stack Canary, PIE/ASLR, architecture target, and identification of dangerous C memory functions.
        </p>
      </div>

      {/* Upload Zone */}
      <div className="bg-cyber-card border border-cyber-border rounded-xl p-6">
        <label className="border-2 border-dashed border-cyber-border hover:border-red-500/50 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer transition-all bg-cyber-dark/40 hover:bg-cyber-dark/80 group">
          <FileCode2 className="w-12 h-12 text-gray-500 group-hover:text-red-400 transition-colors mb-3" />
          <span className="text-sm font-medium text-gray-300 group-hover:text-white">
            {file ? file.name : "Select or drag & drop Linux ELF or Windows PE executable"}
          </span>
          <span className="text-xs text-gray-500 mt-1 font-mono">
            Accepts compiled binaries (no extension, .elf, .exe, .bin, .so)
          </span>
          <input type="file" className="hidden" onChange={handleFileChange} />
        </label>

        {file && (
          <div className="mt-4 flex items-center justify-between bg-cyber-dark px-4 py-3 rounded-lg border border-cyber-border">
            <div className="flex items-center gap-3">
              <Cpu className="w-5 h-5 text-red-400" />
              <div>
                <p className="text-sm font-mono text-white">{file.name}</p>
                <p className="text-xs text-gray-500">{(file.size / 1024).toFixed(1)} KB</p>
              </div>
            </div>
            <button
              onClick={handleInspect}
              disabled={loading}
              className="flex items-center gap-2 px-5 py-2 rounded-lg bg-red-500 text-white font-semibold text-sm hover:bg-red-600 disabled:opacity-50 transition-all font-mono"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  Inspecting ELF Headers...
                </>
              ) : (
                'Run Checksec & Symbols'
              )}
            </button>
          </div>
        )}
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/50 flex items-start gap-3 text-red-200">
          <AlertTriangle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-semibold text-sm">Binary Audit Error</h4>
            <p className="text-xs text-red-300 mt-0.5 font-mono">{error}</p>
          </div>
        </div>
      )}

      {result && (
        <div className="space-y-6">
          <FlagCard flags={result.flags_found || []} source={`Binary (${file?.name})`} />

          {/* Core Info */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-cyber-card border border-cyber-border p-4 rounded-xl font-mono">
              <span className="text-[10px] text-gray-500 uppercase block">Format</span>
              <p className="text-sm font-bold text-white mt-1">{result.format}</p>
            </div>
            <div className="bg-cyber-card border border-cyber-border p-4 rounded-xl font-mono">
              <span className="text-[10px] text-gray-500 uppercase block">Architecture</span>
              <p className="text-sm font-bold text-cyber-cyan mt-1">{result.architecture || `${result.bits}-bit`}</p>
            </div>
            <div className="bg-cyber-card border border-cyber-border p-4 rounded-xl font-mono">
              <span className="text-[10px] text-gray-500 uppercase block">Endianness</span>
              <p className="text-sm font-bold text-gray-300 mt-1">{result.endian || 'N/A'}</p>
            </div>
            <div className="bg-cyber-card border border-cyber-border p-4 rounded-xl font-mono">
              <span className="text-[10px] text-gray-500 uppercase block">Binary Type</span>
              <p className="text-sm font-bold text-purple-400 mt-1">{result.type || 'Standard'}</p>
            </div>
          </div>

          {/* Checksec Mitigations Card */}
          {result.checksec && (
            <div className="bg-cyber-card border border-cyber-border rounded-xl p-5 space-y-4 font-mono">
              <div className="flex items-center gap-2 text-white font-bold text-sm border-b border-cyber-border pb-3 uppercase tracking-wider">
                <ShieldCheck className="w-4 h-4 text-cyber-green" />
                <span>Security Mitigations (Checksec)</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.entries(result.checksec).map(([mitigation, status]: [string, any]) => {
                  const isSafe = String(status).toLowerCase().includes('enabled') || String(status).toLowerCase().includes('found');
                  const isVulnerable = String(status).toLowerCase().includes('disabled') || String(status).toLowerCase().includes('no stack') || String(status).toLowerCase().includes('no pie');

                  return (
                    <div 
                      key={mitigation}
                      className={`p-3.5 rounded-lg border text-xs flex items-start gap-3 ${
                        isVulnerable 
                          ? 'bg-red-950/20 border-red-500/40 text-red-300' 
                          : isSafe 
                          ? 'bg-cyber-green/10 border-cyber-green/30 text-cyber-green' 
                          : 'bg-cyber-darker border-cyber-border text-gray-400'
                      }`}
                    >
                      {isVulnerable ? (
                        <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-cyber-green shrink-0 mt-0.5" />
                      )}
                      <div>
                        <span className="uppercase font-bold text-[11px] block">{mitigation}</span>
                        <p className="text-xs mt-0.5">{status}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Dangerous Imports / Exploitation Vectors */}
          {result.dangerous_imports && (
            <div className="bg-cyber-card border border-red-500/30 rounded-xl p-5 space-y-4 font-mono">
              <div className="flex items-center justify-between border-b border-cyber-border pb-3">
                <span className="text-red-400 font-bold text-sm flex items-center gap-2 uppercase tracking-wider">
                  <Flame className="w-4 h-4 text-red-400" />
                  <span>Exploitable & Dangerous Calls ({result.dangerous_imports.length})</span>
                </span>
                <span className="text-[11px] text-gray-500">Common Pwn targets</span>
              </div>

              {result.dangerous_imports.length === 0 ? (
                <p className="text-xs text-gray-500">No common dangerous functions directly detected in symbol table.</p>
              ) : (
                <div className="space-y-2">
                  {result.dangerous_imports.map((item: any, idx: number) => (
                    <div key={idx} className="bg-cyber-darker p-3 rounded-lg border border-red-500/30 flex items-start justify-between text-xs">
                      <div>
                        <span className="text-white font-bold text-sm font-mono text-red-400">{item.function}()</span>
                        <p className="text-gray-400 text-xs mt-1">{item.risk}</p>
                      </div>
                      <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 text-[10px] uppercase font-bold border border-red-800 shrink-0">
                        ATTACK TARGET
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
