const API_BASE = '/api';

export async function apiRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE}${endpoint}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });
  
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(errorData.detail || `Request failed with status ${res.status}`);
  }
  
  return res.json();
}

// Forensics API
export async function analyzeFile(file: File): Promise<any> {
  const formData = new FormData();
  formData.append('file', file);
  
  const res = await fetch(`${API_BASE}/forensics/analyze`, {
    method: 'POST',
    body: formData,
  });
  
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(errorData.detail || `Forensics upload failed`);
  }
  return res.json();
}

// Binary / Pwn API
export async function inspectBinary(file: File): Promise<any> {
  const formData = new FormData();
  formData.append('file', file);

  const res = await fetch(`${API_BASE}/binary/inspect`, {
    method: 'POST',
    body: formData,
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(errorData.detail || `Binary inspection failed`);
  }
  return res.json();
}

// JWT Studio API
export async function decodeJWT(token: string): Promise<any> {
  return apiRequest('/jwt/decode', {
    method: 'POST',
    body: JSON.stringify({ token }),
  });
}

export async function forgeJWT(header: any, payload: any, secret?: string, alg_none?: boolean): Promise<any> {
  return apiRequest('/jwt/forge', {
    method: 'POST',
    body: JSON.stringify({ header, payload, secret, alg_none }),
  });
}

// Crypto API
export async function decodeText(text: string, context?: string): Promise<any> {
  return apiRequest('/crypto/decode', {
    method: 'POST',
    body: JSON.stringify({ text, context }),
  });
}

export async function caesarAllShifts(text: string): Promise<any> {
  return apiRequest('/crypto/caesar-all', {
    method: 'POST',
    body: JSON.stringify({ text }),
  });
}

export async function vigenereTool(text: string, key: string, decrypt: boolean = true): Promise<any> {
  return apiRequest('/crypto/vigenere', {
    method: 'POST',
    body: JSON.stringify({ text, key, decrypt }),
  });
}

export async function xorBruteforce(text: string, is_hex?: boolean): Promise<any> {
  return apiRequest('/crypto/xor-bruteforce', {
    method: 'POST',
    body: JSON.stringify({ text, is_hex }),
  });
}

export async function convertEndianness(value: string): Promise<any> {
  return apiRequest('/crypto/endianness', {
    method: 'POST',
    body: JSON.stringify({ value }),
  });
}

// RSA API
export async function attackRSA(n: string, e: string, c?: string): Promise<any> {
  return apiRequest('/rsa/attack', {
    method: 'POST',
    body: JSON.stringify({
      n: parseInt(n, 10),
      e: parseInt(e, 10),
      c: c ? parseInt(c, 10) : undefined,
    }),
  });
}

// Hash API
export async function crackHash(hash: string): Promise<any> {
  return apiRequest('/hash/crack', {
    method: 'POST',
    body: JSON.stringify({ hash }),
  });
}

// Web API
export async function huntWeb(url: string): Promise<any> {
  return apiRequest('/web/hunt', {
    method: 'POST',
    body: JSON.stringify({ url }),
  });
}

export async function detectWaf(url: string): Promise<any> {
  return apiRequest('/web/waf-detect', {
    method: 'POST',
    body: JSON.stringify({ url }),
  });
}

export async function mutatePayload(payload: string): Promise<any> {
  return apiRequest('/web/mutate-payload', {
    method: 'POST',
    body: JSON.stringify({ payload }),
  });
}

export async function analyzeJs(url?: string, raw_code?: string): Promise<any> {
  return apiRequest('/web/analyze-js', {
    method: 'POST',
    body: JSON.stringify({ url: url || '', raw_code: raw_code || '' }),
  });
}

// Netcat API
export async function solveNetcat(host: string, port: number): Promise<any> {
  return apiRequest('/netcat/solve', {
    method: 'POST',
    body: JSON.stringify({ host, port }),
  });
}

// Classify API
export async function classifyChallenge(description: string): Promise<any> {
  return apiRequest('/classify', {
    method: 'POST',
    body: JSON.stringify({ description }),
  });
}

// Writeup API
export async function searchWriteups(query: string): Promise<any> {
  return apiRequest('/writeup/search', {
    method: 'POST',
    body: JSON.stringify({ query }),
  });
}

// Chat API
export async function sendChatMessage(messages: { role: string; content: string }[], context?: string): Promise<any> {
  return apiRequest('/chat', {
    method: 'POST',
    body: JSON.stringify({ messages, context }),
  });
}

// License API
export async function getLicenseStatus(): Promise<{
  tier: string;
  status: string;
  signature_valid: boolean;
  expires: string;
  channel: string;
  pro_features: boolean;
}> {
  return apiRequest('/license/status');
}

export async function activateLicense(token: string, license_content?: string): Promise<any> {
  return apiRequest('/license/activate', {
    method: 'POST',
    body: JSON.stringify({ token, license_content: license_content || '' }),
  });
}
