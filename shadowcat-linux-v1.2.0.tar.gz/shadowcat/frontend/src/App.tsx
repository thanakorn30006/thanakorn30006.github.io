import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import { Sidebar, TabType } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { FlagVaultModal } from './components/FlagVaultModal';
import { QuickConverterModal } from './components/QuickConverterModal';
import { Forensics } from './pages/Forensics';
import { Crypto } from './pages/Crypto';
import { RSA } from './pages/RSA';
import { HashCrack } from './pages/HashCrack';
import { WebHunt } from './pages/WebHunt';
import { JWTStudio } from './pages/JWTStudio';
import { BinaryPwn } from './pages/BinaryPwn';
import { PayloadHub } from './pages/PayloadHub';
import { Netcat } from './pages/Netcat';
import { Classify } from './pages/Classify';
import { Writeups } from './pages/Writeups';
import { Chat } from './pages/Chat';

function MainLayout() {
  const [currentTab, setCurrentTab] = useState<TabType>('forensics');
  const [vaultOpen, setVaultOpen] = useState(false);
  const [converterOpen, setConverterOpen] = useState(false);

  const renderContent = () => {
    switch (currentTab) {
      case 'forensics':
        return <Forensics onNavigateToChat={() => setCurrentTab('chat')} />;
      case 'crypto':
        return <Crypto />;
      case 'rsa':
        return <RSA />;
      case 'hash':
        return <HashCrack />;
      case 'web':
        return <WebHunt />;
      case 'jwt':
        return <JWTStudio />;
      case 'binary':
        return <BinaryPwn />;
      case 'payloads':
        return <PayloadHub />;
      case 'netcat':
        return <Netcat />;
      case 'classify':
        return <Classify />;
      case 'writeup':
        return <Writeups />;
      case 'chat':
        return <Chat />;
      default:
        return <Forensics onNavigateToChat={() => setCurrentTab('chat')} />;
    }
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-cyber-darker text-gray-200">
      {/* Navigation Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        onOpenVault={() => setVaultOpen(true)}
      />

      {/* Main Container */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Navbar */}
        <TopBar
          onOpenVault={() => setVaultOpen(true)}
          onOpenConverter={() => setConverterOpen(true)}
        />

        {/* Workspace Canvas */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#090d16]">
          {renderContent()}
        </main>
      </div>

      {/* Flag Vault Dialog */}
      <FlagVaultModal isOpen={vaultOpen} onClose={() => setVaultOpen(false)} />

      {/* Quick Scratchpad Dialog */}
      <QuickConverterModal isOpen={converterOpen} onClose={() => setConverterOpen(false)} />
    </div>
  );
}

export function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}

export default App;
