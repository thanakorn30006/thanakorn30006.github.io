import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.voice import announce_flag

router = APIRouter()

class RSARequest(BaseModel):
    n: int
    e: int
    c: Optional[int] = None

@router.post("/attack")
async def rsa_attack(req: RSARequest):
    """Run RSA attacks: small N factoring, Wiener, cube root (e=3), FactorDB."""
    try:
        from core.ctf_agent import rsa_attack as _rsa
        result = _rsa(req.n, req.e, req.c)
        if result.get("flags"):
            announce_flag(result["flags"][0])
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
