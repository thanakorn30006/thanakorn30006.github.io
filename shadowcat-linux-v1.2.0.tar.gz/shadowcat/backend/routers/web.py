import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, List, Any

sys.path.insert(0, str(Path(__file__).parent.parent))

router = APIRouter()

class WebRequest(BaseModel):
    url: str
    headers: Optional[Dict[str, str]] = {}
    cookies: Optional[Dict[str, str]] = {}

class WafProbeRequest(BaseModel):
    url: str

class MutatePayloadRequest(BaseModel):
    payload: str

class JsAnalysisRequest(BaseModel):
    url: Optional[str] = ""
    raw_code: Optional[str] = ""

@router.post("/hunt")
async def web_hunt(req: WebRequest):
    """Hunt for CTF flags in a web target: source, headers, common paths, payloads."""
    try:
        from core.ctf_agent import web_hunt_flag
        result = web_hunt_flag(req.url, req.headers or {}, req.cookies or {})
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/waf-detect")
async def detect_waf_endpoint(req: WafProbeRequest):
    """Probe target URL and fingerprint active Web Application Firewalls (Cloudflare, AWS, ModSec, etc.)."""
    try:
        from core.waf_engine import probe_waf
        result = await probe_waf(req.url)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/mutate-payload")
def mutate_payload_endpoint(req: MutatePayloadRequest):
    """Generate high-yield WAF evasion variants (URL encoding, comment splitting, case jittering, space bypass)."""
    try:
        from core.waf_engine import mutate_payload_variants
        variants = mutate_payload_variants(req.payload)
        return {"variants": variants, "count": len(variants)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/analyze-js")
async def analyze_js_endpoint(req: JsAnalysisRequest):
    """Extract hidden API endpoints, routes, tokens, and leaked secrets from JavaScript assets."""
    try:
        from core.js_hunter import analyze_target_js
        result = await analyze_target_js(req.url or "", req.raw_code or "")
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
