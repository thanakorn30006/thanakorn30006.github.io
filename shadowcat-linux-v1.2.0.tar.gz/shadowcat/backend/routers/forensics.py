import sys, shutil, os, hashlib, re, zipfile, tempfile
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse, FileResponse

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.config import UPLOAD_DIR
from core.voice import announce_flag

router = APIRouter()

def generate_hexdump(data: bytes, max_bytes: int = 1024) -> str:
    lines = []
    chunk = data[:max_bytes]
    for i in range(0, len(chunk), 16):
        row = chunk[i:i+16]
        hex_bytes = " ".join(f"{b:02x}" for b in row)
        ascii_repr = "".join(chr(b) if 32 <= b <= 126 else "." for b in row)
        lines.append(f"{i:08x}  {hex_bytes:<48}  |{ascii_repr}|")
    return "\n".join(lines)

@router.post("/analyze")
async def analyze_file(file: UploadFile = File(...)):
    """Upload a file and run full CTF forensics analysis."""
    try:
        from core.ctf_agent import analyze_file as _analyze, extract_strings
        
        # Clean filename to prevent injection / path traversal
        clean_name = re.sub(r'[^A-Za-z0-9_.\-]', '_', file.filename or 'upload.bin')
        dest = UPLOAD_DIR / clean_name
        
        # Read content and compute hashes
        content = await file.read()
        with open(dest, "wb") as f:
            f.write(content)
            
        md5_hash = hashlib.md5(content).hexdigest()
        sha1_hash = hashlib.sha1(content).hexdigest()
        sha256_hash = hashlib.sha256(content).hexdigest()
        hexdump_preview = generate_hexdump(content, max_bytes=1024)
        
        # Run deep forensic pipeline
        result = _analyze(str(dest))
        
        # Announce via voice if flag found
        if result.get("flags_found"):
            announce_flag(result["flags_found"][0])
            
        # Extract strings for search/filter table
        str_res = extract_strings(str(dest), min_len=4)
        interesting_strings = str_res.get("interesting_strings", [])[:300]
        
        # Enrich result
        result["file_meta"] = {
            "filename": clean_name,
            "size_bytes": len(content),
            "md5": md5_hash,
            "sha1": sha1_hash,
            "sha256": sha256_hash,
            "hexdump": hexdump_preview,
            "strings_count": str_res.get("total_strings", 0),
            "sample_strings": interesting_strings
        }
        
        # Check if any extracted/carved files exist
        extracted_dir = UPLOAD_DIR / "extracted"
        extracted_count = len([f for f in extracted_dir.glob("*") if f.is_file()]) if extracted_dir.exists() else 0
        result["extracted_artifacts_count"] = extracted_count
        
        return JSONResponse(content=result)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/download-extracted")
async def download_extracted_artifacts():
    """Package all carved and extracted artifacts from /tmp/ctf_uploads/extracted into a downloadable zip file."""
    try:
        extracted_dir = UPLOAD_DIR / "extracted"
        if not extracted_dir.exists():
            raise HTTPException(status_code=404, detail="No extracted artifacts directory found.")
            
        files = [p for p in extracted_dir.rglob("*") if p.is_file()]
        if not files:
            raise HTTPException(status_code=404, detail="No carved artifacts currently available in extracted directory.")
            
        # Create temp zip file
        temp_zip = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
        with zipfile.ZipFile(temp_zip.name, "w", zipfile.ZIP_DEFLATED) as zf:
            for file_path in files:
                arcname = file_path.relative_to(extracted_dir)
                zf.write(file_path, arcname=str(arcname))
                
        return FileResponse(
            path=temp_zip.name,
            filename="shadowsolve_carved_artifacts.zip",
            media_type="application/zip"
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
