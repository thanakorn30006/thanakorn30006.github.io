import sys, os, struct, re
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.config import UPLOAD_DIR

router = APIRouter()

DANGEROUS_FUNCTIONS = {
    "gets": "Extreme risk: unbounded buffer overflow (gets has no buffer limits)",
    "strcpy": "High risk: unbounded string copy without size checking",
    "strcat": "High risk: unbounded string concatenation",
    "sprintf": "High risk: string formatting without bounds checking",
    "vsprintf": "High risk: variable arguments formatting without bounds",
    "system": "Exploitable: command execution vector (ret2libc / ROP target)",
    "execve": "Exploitable: syscall to spawn shell or execute arbitrary binary",
    "popen": "Exploitable: process execution pipeline",
    "printf": "Format string risk if user input passed directly without format specifier",
    "scanf": "Buffer overflow risk if %s used without width limit",
    "ptrace": "Anti-debugging technique detector",
    "memcmp": "Potential flag verification comparison target",
    "strcmp": "Potential flag verification comparison target",
    "strncmp": "Potential flag verification comparison target",
}

def analyze_elf_binary(filepath: str, data: bytes) -> dict:
    """Analyze Linux ELF binary for architecture, checksec mitigations, and dangerous functions."""
    result = {
        "format": "ELF (Executable and Linkable Format)",
        "bits": 64 if data[4] == 2 else 32,
        "endian": "Little Endian" if data[5] == 1 else "Big Endian",
        "os_abi": "System V" if data[7] == 0 else "Linux" if data[7] == 3 else f"ABI {data[7]}",
        "type": "Executable" if data[16] == 2 else "Shared Object / PIE" if data[16] == 3 else "Relocatable",
        "checksec": {
            "nx": "Unknown",
            "canary": "Unknown",
            "pie": "Unknown",
            "relro": "Unknown",
        },
        "dangerous_imports": [],
        "interesting_strings": [],
    }

    # PIE check
    if data[16] == 3:
        result["checksec"]["pie"] = "PIE enabled (Shared Object/DYN)"
    elif data[16] == 2:
        result["checksec"]["pie"] = "No PIE (Executable/EXEC - Fixed Addresses)"

    # Architecture
    machine_id = struct.unpack("<H" if data[5] == 1 else ">H", data[18:20])[0]
    arch_map = {0x03: "x86 (32-bit)", 0x3E: "x86_64 (AMD64)", 0x28: "ARM (32-bit)", 0xB7: "AArch64 (ARM64)", 0x08: "MIPS"}
    result["architecture"] = arch_map.get(machine_id, f"Machine ID: 0x{machine_id:02x}")

    # Inspect program headers for GNU_STACK (NX flag)
    try:
        is_64 = (data[4] == 2)
        endian = "<" if data[5] == 1 else ">"
        phoff = struct.unpack(f"{endian}{'Q' if is_64 else 'I'}", data[32:40] if is_64 else data[28:32])[0]
        phentsize = struct.unpack(f"{endian}H", data[54:56] if is_64 else data[42:44])[0]
        phnum = struct.unpack(f"{endian}H", data[56:58] if is_64 else data[44:46])[0]

        nx_found = False
        for i in range(phnum):
            offset = phoff + i * phentsize
            if offset + phentsize <= len(data):
                p_type = struct.unpack(f"{endian}I", data[offset:offset+4])[0]
                if p_type == 0x6474e551:  # PT_GNU_STACK
                    p_flags = struct.unpack(f"{endian}I", data[offset+4:offset+8])[0] if is_64 else struct.unpack(f"{endian}I", data[offset+24:offset+28])[0]
                    # PF_X is 0x1
                    if (p_flags & 1) == 0:
                        result["checksec"]["nx"] = "NX Enabled (Stack not executable)"
                    else:
                        result["checksec"]["nx"] = "NX Disabled (Stack EXECUTABLE - Shellcode ready!)"
                    nx_found = True
                    break
        if not nx_found:
            result["checksec"]["nx"] = "No PT_GNU_STACK found (Likely executable stack)"
    except Exception:
        pass

    # Scan for symbols / imports
    symbols = set(re.findall(rb'[A-Za-z0-9_]{3,40}', data))
    symbols_str = [s.decode('latin-1') for s in symbols]
    
    # Canary check
    if "__stack_chk_fail" in symbols_str or "__stack_chk_guard" in symbols_str:
        result["checksec"]["canary"] = "Stack Canary Found (__stack_chk_fail present)"
    else:
        result["checksec"]["canary"] = "No Stack Canary Found (Buffer overflow feasible!)"

    # Dangerous functions
    for func, desc in DANGEROUS_FUNCTIONS.items():
        if func in symbols_str:
            result["dangerous_imports"].append({"function": func, "risk": desc})

    # Strings
    from core.ctf_agent import search_flags
    raw_text = data.decode('latin-1', errors='ignore')
    flags = search_flags(raw_text)
    result["flags_found"] = flags

    return result

def analyze_pe_binary(data: bytes) -> dict:
    """Analyze Windows PE (Portable Executable) binary."""
    result = {
        "format": "PE (Windows Executable / DLL)",
        "bits": 32,
        "checksec": {
            "dep": "Unknown",
            "aslr": "Unknown",
            "cfg": "Unknown",
        },
        "dangerous_imports": [],
        "flags_found": []
    }
    symbols = set(re.findall(rb'[A-Za-z0-9_]{3,40}', data))
    symbols_str = [s.decode('latin-1') for s in symbols]

    for func, desc in DANGEROUS_FUNCTIONS.items():
        if func in symbols_str:
            result["dangerous_imports"].append({"function": func, "risk": desc})

    from core.ctf_agent import search_flags
    raw_text = data.decode('latin-1', errors='ignore')
    result["flags_found"] = search_flags(raw_text)
    return result

@router.post("/inspect")
async def inspect_binary(file: UploadFile = File(...)):
    """Upload an ELF or PE binary for Checksec mitigations & dangerous function audits."""
    try:
        content = await file.read()
        if content.startswith(b'\x7fELF'):
            analysis = analyze_elf_binary(file.filename, content)
        elif content.startswith(b'MZ'):
            analysis = analyze_pe_binary(content)
        else:
            raise HTTPException(status_code=400, detail="File is neither an ELF nor PE executable binary")

        analysis["filename"] = file.filename
        analysis["size_bytes"] = len(content)
        return JSONResponse(content=analysis)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
