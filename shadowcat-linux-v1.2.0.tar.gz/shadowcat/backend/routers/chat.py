import sys, json
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.config import (
    GEMINI_API_KEY, PRIMARY_MODEL,
    PSU_AI_API_KEY, PSU_AI_BASE_URL, PSU_AI_MODEL, PREFERRED_AI_PROVIDER
)

router = APIRouter()

CTF_SYSTEM_PROMPT = """You are ShadowSolve, an expert elite CTF (Capture The Flag) AI assistant.
You specialize in all CTF categories:
- 🔐 Crypto: ciphers, encoding, RSA, hash cracking, lattice, discrete log
- 🕵️ Forensics: file analysis, steganography, PCAP traffic, memory dumps, EVTX logs, MBR/FAT/NTFS carving
- 🌐 Web: SQLi, XSS, LFI, SSTI, JWT, SSRF, XXE, deserialization, request smuggling
- 💥 Pwn: buffer overflow, ROP chains, format string, heap exploitation (tcache, fastbin)
- 🔬 Rev: binary reversing, decompilation, anti-debug, angr, Z3, assembly
- 🎲 Misc: OSINT, esoteric languages, jail escape, scripting

Be concise, practical, and provide immediate working code or terminal commands.
Always think step-by-step. If given a cipher or payload, analyze and attack it.
Flag format examples: picoCTF{...}, flag{...}, HTB{...}, CTF{...}, etc."""

class ChatMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str

class ChatRequest(BaseModel):
    messages: List[ChatMessage]
    context: Optional[str] = None

async def _chat_psu(messages: List[ChatMessage], context: Optional[str] = None) -> str:
    from openai import OpenAI
    client = OpenAI(api_key=PSU_AI_API_KEY, base_url=PSU_AI_BASE_URL, timeout=30.0)
    sys_content = CTF_SYSTEM_PROMPT
    if context:
        sys_content += f"\n\nCURRENT CHALLENGE CONTEXT:\n{context}"
    msgs = [{"role": "system", "content": sys_content}]
    for m in messages:
        msgs.append({"role": m.role, "content": m.content})
    response = client.chat.completions.create(model=PSU_AI_MODEL, messages=msgs)
    return response.choices[0].message.content or ""

async def _chat_gemini(messages: List[ChatMessage], context: Optional[str] = None) -> str:
    import google.generativeai as genai
    genai.configure(api_key=GEMINI_API_KEY)
    sys_content = CTF_SYSTEM_PROMPT
    if context:
        sys_content += f"\n\nCURRENT CHALLENGE CONTEXT:\n{context}"
    model = genai.GenerativeModel(PRIMARY_MODEL, system_instruction=sys_content)
    history = []
    for m in messages[:-1]:
        history.append({"role": "user" if m.role == "user" else "model", "parts": [m.content]})
    chat = model.start_chat(history=history)
    response = chat.send_message(messages[-1].content)
    return response.text or ""

@router.post("")
async def chat(req: ChatRequest):
    """AI chat for CTF help with automatic dual-provider fallback."""
    errors = []
    
    # 1. First choice: Preferred Provider
    if PREFERRED_AI_PROVIDER == "psu_ai" and PSU_AI_API_KEY:
        try:
            reply = await _chat_psu(req.messages, req.context)
            if reply: return {"reply": reply, "provider": "psu_ai"}
        except Exception as e:
            errors.append(f"PSU AI failed: {e}")
            
    if GEMINI_API_KEY:
        try:
            reply = await _chat_gemini(req.messages, req.context)
            if reply: return {"reply": reply, "provider": "gemini"}
        except Exception as e:
            errors.append(f"Gemini failed: {e}")

    # Fallback to the other if primary was gemini
    if PREFERRED_AI_PROVIDER != "psu_ai" and PSU_AI_API_KEY:
        try:
            reply = await _chat_psu(req.messages, req.context)
            if reply: return {"reply": reply, "provider": "psu_ai"}
        except Exception as e:
            errors.append(f"PSU AI fallback failed: {e}")

    if errors:
        return {"reply": f"⚠️ AI service unavailable:\n" + "\n".join(errors)}
    return {"reply": "No AI API key configured in .env (add GEMINI_API_KEY or PSU_AI_API_KEY)"}
