import sys
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

sys.path.insert(0, str(Path(__file__).parent.parent))

router = APIRouter()

class HashRequest(BaseModel):
    hash: str

@router.post("/crack")
async def crack_hash(req: HashRequest):
    """Crack hash using CrackStation, md5decrypt.net, hashes.com, and local DB."""
    try:
        from core.ctf_ml import ctf_hash_crack
        result = ctf_hash_crack(req.hash)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
