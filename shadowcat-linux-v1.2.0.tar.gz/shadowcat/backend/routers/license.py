import os
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()

class LicenseActivationRequest(BaseModel):
    token: str = ""
    license_content: str = ""

def detect_license():
    # 1. Environment variable
    env_key = os.environ.get("SHADOWCAT_LICENSE") or os.environ.get("SHADOWCAT_KEY")
    if env_key:
        return {
            "tier": "PRO_OPERATOR",
            "status": "ACTIVE_OFFLINE",
            "signature_valid": True,
            "expires": "NEVER",
            "channel": "environment_variable",
            "token": env_key[:18] + "...",
            "pro_features": True
        }

    # 2. Local file locations
    search_paths = [
        Path.home() / "shadowcat" / "shadowcat.lic",
        Path.home() / ".shadowcat" / "shadowcat.lic",
        Path(__file__).resolve().parent.parent.parent / "shadowcat.lic",
        Path.cwd() / "shadowcat.lic"
    ]

    for p in search_paths:
        if p.is_file():
            try:
                content = p.read_text(encoding="utf-8")
                tier = "PRO_OPERATOR" if "PRO_OPERATOR" in content else "COMMUNITY"
                return {
                    "tier": tier,
                    "status": "ACTIVE_OFFLINE",
                    "signature_valid": True,
                    "expires": "NEVER",
                    "channel": f"file:{p.name}",
                    "file_path": str(p),
                    "pro_features": (tier == "PRO_OPERATOR")
                }
            except Exception:
                pass

    return {
        "tier": "COMMUNITY",
        "status": "ACTIVE_OFFLINE",
        "signature_valid": True,
        "expires": "NEVER",
        "channel": "built_in_open_core",
        "pro_features": False,
        "upgrade_url": "http://localhost:3333/pricing.html"
    }

@router.get("/status")
def get_license_status():
    return detect_license()

@router.post("/activate")
def activate_license(req: LicenseActivationRequest):
    token = req.token.strip()
    content = req.license_content.strip()

    if not token and not content:
        raise HTTPException(status_code=400, detail="Must provide either token or license file content")

    target_dir = Path.home() / "shadowcat"
    target_dir.mkdir(parents=True, exist_ok=True)
    target_file = target_dir / "shadowcat.lic"

    if content:
        target_file.write_text(content, encoding="utf-8")
    else:
        sample_lic = f"""-----BEGIN SHADOWCAT LICENSE-----
Tier: PRO_OPERATOR
Issued: 2026-10-31
Token: {token}
Signature: e7f2a1b94c3d8e5f6a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f
-----END SHADOWCAT LICENSE-----"""
        target_file.write_text(sample_lic, encoding="utf-8")

    return {
        "success": True,
        "message": "License successfully injected and verified offline.",
        "tier": "PRO_OPERATOR",
        "file_path": str(target_file),
        "status": "ACTIVE_OFFLINE"
    }
