import os
from dotenv import load_dotenv
from pathlib import Path

load_dotenv(Path(__file__).parent.parent / ".env")

# Gemini
GEMINI_API_KEYS = [k.strip() for k in os.getenv("GEMINI_API_KEYS", "").split(",") if k.strip()]
GEMINI_API_KEY = GEMINI_API_KEYS[0] if GEMINI_API_KEYS else os.getenv("GEMINI_API_KEY", "")
if GEMINI_API_KEY and not os.environ.get("GEMINI_API_KEY"):
    os.environ["GEMINI_API_KEY"] = GEMINI_API_KEY
PRIMARY_MODEL = os.getenv("PRIMARY_MODEL", "gemini-1.5-flash")

# PSU AI
PSU_AI_API_KEY = os.getenv("PSU_AI_API_KEY", os.getenv("OPENAI_API_KEY", ""))
PSU_AI_BASE_URL = os.getenv("PSU_AI_BASE_URL", "https://api.psu.ac.th/v1")
PSU_AI_MODEL = os.getenv("PSU_AI_MODEL", "psu-gpt-4o")
PREFERRED_AI_PROVIDER = os.getenv("PREFERRED_AI_PROVIDER", "psu_ai")

# Models and Upload dir
MODELS_DIR = Path(__file__).parent.parent / "models"
UPLOAD_DIR = Path("/tmp/ctf_uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
